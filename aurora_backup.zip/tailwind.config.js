/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        aurora1: "#ec4899", // pink
        aurora2: "#f97316", // orange
        aurora3: "#ef4444", // red
        aurora4: "#a855f7", // violet
      },
      backgroundImage: {
        aurora: "linear-gradient(135deg, #ec4899, #f97316, #ef4444, #a855f7)",
      },
      keyframes: {
        auroraFlow: {
          "0%, 100%": { backgroundPosition: "0% 50%" },
          "50%": { backgroundPosition: "100% 50%" },
        },
      },
      animation: {
        auroraFlow: "auroraFlow 18s ease infinite",
      },
    },
  },
  plugins: [],
};