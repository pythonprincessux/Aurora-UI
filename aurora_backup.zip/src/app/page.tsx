"use client";
import React, { useState } from "react";

export default function Home() {
  const [playlist, setPlaylist] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);

  // Fetch shuffled data from API
  const fetchShuffle = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/shuffle");
      const data = (await res.json()) as any; // ✅ fixes the "unknown" error
      setPlaylist(data.tracks || []);
    } catch (err) {
      console.error("Shuffle failed:", err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="min-h-screen flex flex-col items-center justify-center text-center text-white relative overflow-hidden bg-gradient-to-br from-black via-[#090913] to-[#0a0a0f] animate-[aurora_14s_ease-in-out_infinite]">
      {/* Aurora Header */}
      <h1 className="text-6xl font-extrabold drop-shadow-2xl tracking-wide z-10 text-transparent bg-clip-text bg-gradient-to-r from-pink-400 via-orange-400 to-violet-400 animate-[shimmer_6s_linear_infinite]">
        🎧 Aurora Shuffle
      </h1>

      {/* Shuffle Button */}
      <button
        onClick={fetchShuffle}
        className="z-10 mt-8 relative px-6 py-3 rounded-full font-semibold text-lg transition-all duration-500 
        bg-gradient-to-r from-pink-500 via-orange-500 to-red-500 
        shadow-[0_0_25px_rgba(236,72,153,0.5)] hover:shadow-[0_0_35px_rgba(236,72,153,0.8)] 
        text-white hover:scale-105 animate-pulseGlow"
      >
        {loading ? "Shuffling..." : "Shuffle Tracks"}
      </button>

      {/* Playlist Results */}
      <ul className="mt-10 space-y-3 z-10">
        {playlist.map((track, i) => (
          <li
            key={i}
            className="text-lg bg-white/10 rounded-xl px-3 py-2 w-80 mx-auto shadow-md backdrop-blur-md hover:bg-white/20 transition-all"
          >
            {i + 1}. {track}
          </li>
        ))}
      </ul>

      {/* Footer Glow Text */}
<div className="absolute bottom-10 text-sm opacity-80 tracking-wide glow-text">
  ✨ Made with 💖 by Kiara ✨
</div>
</main>
);
}