// ✅ Fixed PostCSS config (for Next.js + Tailwind 4)
module.exports = {
  plugins: {
    '@tailwindcss/postcss': {},
    autoprefixer: {},
  },
};